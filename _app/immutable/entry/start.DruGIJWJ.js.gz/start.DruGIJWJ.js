import{a as t}from"../chunks/BdrHcTdD.js";export{t as start};
