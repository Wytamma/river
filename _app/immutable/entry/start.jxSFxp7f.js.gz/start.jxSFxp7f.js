import{a as t}from"../chunks/DKallSaK.js";export{t as start};
