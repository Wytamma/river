import{a as t}from"../chunks/BMdzPAru.js";export{t as start};
