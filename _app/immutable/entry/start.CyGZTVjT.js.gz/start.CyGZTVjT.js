import{a as t}from"../chunks/D5VU2OLh.js";export{t as start};
